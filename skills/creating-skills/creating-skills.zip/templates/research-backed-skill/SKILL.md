---
name: replace-with-research-skill-name
description: Converts research, transcripts, source notes, or examples into a reusable workflow. Use when the user asks to make a skill from research material, pasted notes, uploaded transcripts, or prior prompt iterations.
---

# Research-Backed Skill Template


<!-- Replace placeholders. Keep SKILL.md concise. Move bulk details to reference/. -->


## Purpose

Turn dense source material into a concise reusable skill.

## Source handling

Extract durable operational patterns:

- trigger phrases
- repeated steps
- decision rules
- constraints
- examples
- errors to avoid
- validation scenarios
- scripts/tools worth saving

Do not paste raw research into `SKILL.md`. Store summaries in `reference/`.

## Workflow

1. Inventory the sources.
2. Separate stable rules from one-off context.
3. Draft concise frontmatter.
4. Create the main workflow.
5. Move long notes to `reference/source-summary.md`.
6. Add examples or templates only if they materially improve reuse.
7. Add evals.

## Additional resources

- For source summaries, read `reference/source-summary.md`.
- For examples, read `reference/examples.md`.
- For evals, read `reference/evals.md`.
